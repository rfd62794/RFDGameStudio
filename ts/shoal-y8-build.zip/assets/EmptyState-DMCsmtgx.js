import{j as e}from"./index-uKzPkVDD.js";function r({message:t}){return e.jsx("div",{className:"empty-state",children:t})}export{r as E};
