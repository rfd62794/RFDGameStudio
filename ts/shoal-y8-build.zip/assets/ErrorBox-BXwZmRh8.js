import{j as o}from"./index-uKzPkVDD.js";function e({message:r}){return o.jsx("div",{className:"error-box",children:r})}export{e as E};
