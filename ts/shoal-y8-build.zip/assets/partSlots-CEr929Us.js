const e=["head","chest","left_arm","right_arm","left_leg","right_leg"];export{e as P};
